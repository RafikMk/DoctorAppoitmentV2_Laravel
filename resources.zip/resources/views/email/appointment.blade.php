Dear {{ $data->name }},

<p>Thank you for booking an appointment via our website. Kindly find the details of your appointment below.</p>

<p>Doctor: {{ $data->doctor }}</p>
<p>Date: {{ $data->date }}</p>
<p>Time: {{ $data->time }}</p>

Contact us at <i>(234) 81 884 69918</i> if you have any more enquiries.